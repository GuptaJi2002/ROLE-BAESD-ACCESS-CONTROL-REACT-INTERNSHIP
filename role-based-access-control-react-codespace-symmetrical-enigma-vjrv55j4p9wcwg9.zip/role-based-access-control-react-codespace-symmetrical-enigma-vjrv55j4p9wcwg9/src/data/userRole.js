export const userRoles = {
    customer: "Customer",
    admin: "Admin",
}