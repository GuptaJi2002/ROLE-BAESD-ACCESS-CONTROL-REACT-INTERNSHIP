const ApplyLoanPage = ()=>{
    return(
        <div className="container mt-3">
            You can apply for a loan here...
        </div>
    );
}
export default ApplyLoanPage;