const LoanSchemePage = ()=>{
    return(
        <div className="container mt-3">
            Available Loan schemes are...
        </div>
    );
}
export default LoanSchemePage;