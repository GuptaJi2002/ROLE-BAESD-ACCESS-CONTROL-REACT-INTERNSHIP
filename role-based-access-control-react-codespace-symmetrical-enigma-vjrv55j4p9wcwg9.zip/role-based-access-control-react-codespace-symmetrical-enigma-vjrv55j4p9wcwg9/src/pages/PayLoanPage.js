const PayLoanPage = ()=>{
    return(
        <div className="container mt-3">
            You can pay your loan here...
        </div>
    );
}
export default PayLoanPage;